// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#include "epoll.h"
#include "log.h"
#include "qman.h"
#include "utils.h"
#include <demi/libos.h>
#include <errno.h>
#include <glue.h>

int __init()
{
    int ret = -1;
    int argc = 1;

printf("__INIT\n");
    char *const argv[] = {"shim"};

    // TODO: Pass down arguments correctly.
    TRACE("argc=%d argv={%s}", argc, argv[0]);

printf("queue_man_init...\n");
    queue_man_init();
printf("epoll_table_init...\n");
    epoll_table_init();
printf("demi_init...\n");
//     ret = __demi_init(argc, argv);
// printf("DEMI_INIT retornou=%d\n", ret);
//     if (ret != 0)
//     {
//         errno = ret;
//         return -1;
//     }

    return 0;
}
