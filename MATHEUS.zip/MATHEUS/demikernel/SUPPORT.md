# Support

## How to File Issues and Get Help

This project uses GitHub Issues to track bugs and feature requests. Please search the existing
issues before filing new issues to avoid duplicates. For new issues, file your bug or
feature request as a new Issue.

For help and questions about using this project, please reach out to our community in
[Slack](https://join.slack.com/t/demikernel/shared_invite/zt-11i6lgaw5-HFE_IAls7gUX3kp1XSab0g).

## Microsoft Support Policy

Support for this project is limited to the resources listed above.
