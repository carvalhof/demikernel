License Notes
==============

_Demikernel_ uses the following open source software:

- [DPDK](https://www.dpdk.org/) (BSD)