// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#![allow(non_camel_case_types)]

//==============================================================================
// Types
//==============================================================================

/// Queue Token
pub type demi_qtoken_t = u64;
