// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

pub mod hashttlcache;

pub use hashttlcache::HashTtlCache;
